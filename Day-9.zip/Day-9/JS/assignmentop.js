var x = 100;
x += 50;


document.write(x,"<br/>");

var a = 100;
a -= 50;

document.write(a,"<br/>");

var b = 100;
b *= 50;

document.write(b,"<br/>");

var c = 100;
c /= 50;

document.write(c,"<br/>");

var d = 100;
d == 50;
document.write(d,"<br/>");

var aa = 100;
aa %= 50;

document.write(aa,"<br/>");

var da = 100;
da **= 50;

document.write(da,"<br/>");
var dc = 100;
dc >= 50;

document.write(dc,"<br/>");
var dd = 100;
dd <= 50;

document.write(dd,"<br/>");
var dbd = 100;
dbd >>= 5;

document.write(dbd,"<br/>");

var db = 100;
db <<= 5;

document.write(db,"<br/>");
var dv = 100;
dv >>>= 5;

document.write(dv,"<br/>");
var dz = 100;
dz &= 50;

document.write(dz,"<br/>");
var q = 100;
q ^= 50;

document.write(q,"<br/>");

var w = 100;
w |= 50;

document.write(w,"<br/>");
var f = 100;
f &&= 50;

document.write(f,"<br/>");
var g = 100;
g ||= 5;

document.write(g,"<br/>");
var h = 100;
h ??= 5;

document.write(h,"<br/>");

